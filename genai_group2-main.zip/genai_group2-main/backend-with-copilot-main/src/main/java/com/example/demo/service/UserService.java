package com.example.demo.service;

import java.util.Optional;

import com.example.demo.model.UserProfile;

public interface UserService {
    UserProfile createUserProfile(UserProfile userProfile);
    UserProfile updateUserProfile(String username, UserProfile userProfile);
    Optional<UserProfile> getUserProfile(String username);
    void deleteUserProfile(String username);
    UserProfile login(String username, String password);
    void forgotPassword(String username);
}