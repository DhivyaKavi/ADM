package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.UserProfile;
import com.example.demo.service.UserService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserProfileController {
    @Autowired
    private UserService userService;

    @PostMapping("/create")
    public ResponseEntity<UserProfile> createUserProfile(@Valid @RequestBody UserProfile userProfile) {
        return ResponseEntity.ok(userService.createUserProfile(userProfile));
    }

    @PutMapping("/update/{username}")
    public ResponseEntity<UserProfile> updateUserProfile(@PathVariable String username, @Valid @RequestBody UserProfile userProfile) {
        return ResponseEntity.ok(userService.updateUserProfile(username, userProfile));
    }

    @GetMapping("/get/{username}")
    public ResponseEntity<Optional<UserProfile>> getUserProfile(@PathVariable String username) {
        return ResponseEntity.ok(userService.getUserProfile(username));
    }

    @DeleteMapping("/delete/{username}")
    public ResponseEntity<Void> deleteUserProfile(@PathVariable String username) {
        userService.deleteUserProfile(username);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserProfile userProfile) {
        String username = userProfile.getUsername();
        String password = userProfile.getPassword();
        if(userService.login(username, password) != null) {
            return ResponseEntity.ok("Login successful");
        }
        return ResponseEntity.notFound().build();
    }
        

    @PostMapping("/forgot-password/{username}")
    public ResponseEntity<?> forgotPassword(@PathVariable String username) {
        userService.forgotPassword(username);
        return ResponseEntity.ok("Your temporat password is Temp@123");
    }
}

