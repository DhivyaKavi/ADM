package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.UserProfile;
import com.example.demo.repository.UserProfileRepository;



@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserProfileRepository userProfileRepository;

    // @Autowired
    // private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public UserProfile createUserProfile(UserProfile userProfile) {
        if (userProfileRepository.findByUsername(userProfile.getUsername()).isPresent()) {
            throw new RuntimeException("Username is already taken.");
        }
        if (userProfileRepository.findByEmail(userProfile.getEmail()).isPresent()) {
            throw new RuntimeException("Email is already taken.");
        }
        // userProfile.setPassword(bCryptPasswordEncoder.encode(userProfile.getPassword()));
        return userProfileRepository.save(userProfile);
    }

    @Override
    public UserProfile updateUserProfile(String username, UserProfile userProfile) {
        UserProfile existingProfile = userProfileRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found."));
        existingProfile.setEmail(userProfile.getEmail());
        existingProfile.setPassword(userProfile.getPassword());
        return userProfileRepository.save(existingProfile);
    }

    @Override
    public Optional<UserProfile> getUserProfile(String username) {
        return userProfileRepository.findByUsername(username);
    }

    @Override
    public void deleteUserProfile(String username) {
        userProfileRepository.findByUsername(username);
    }

    @Override
    public UserProfile login(String username, String password) {
        UserProfile userProfile = userProfileRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Invalid username or password."));
        if (!password.equals(userProfile.getPassword())) {
            throw new RuntimeException("Invalid username or password.");
        }
        return userProfile;
    }

    @Override
    public void forgotPassword(String username) {
        UserProfile userProfile = userProfileRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found."));
        userProfile.setPassword(("Temp@123"));
        userProfileRepository.save(userProfile);
    }
    
}
