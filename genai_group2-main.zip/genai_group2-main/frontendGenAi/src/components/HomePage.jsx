import React from 'react';
import { Button, Container, Row, Col } from 'react-bootstrap';
import CarouselComponent from './CarouselComponent';
import CardsComponent from './CardsComponent';
import { Link } from 'react-router-dom';
import Footer from './Footer';
import './HomePage.css';

function HomePage() {
  return (
    <div className="home-page">
      <div className="content">
        <Container>
          <Row className="justify-content-center align-items-center text-center">
            <Col md={6}>
              <h1 className="display-4 text-black">Welcome to HeartSync</h1>
              <p className="lead text-black">Your trusted cardiac diagnosis system</p>
              <div className="button-group">
              <Link to="/login">
                <Button variant="primary" size="lg" className="mr-3">Login</Button>
                </Link>
                <Link to="/register">
                <Button variant="secondary" size="lg" href="#register">Register</Button>
                </Link>
              </div>
            </Col>
          </Row>
          <Row className="mt-5">
            <Col>
              <CarouselComponent />
            </Col>
          </Row>
          <Row className="mt-5">
            <Col>
              <CardsComponent />
            </Col>
          </Row>
        </Container>
      </div>
      <Footer />
    </div>
  );
}

export default HomePage;
