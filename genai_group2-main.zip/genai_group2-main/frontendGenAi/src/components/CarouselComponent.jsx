import React from 'react';
import { Carousel } from 'react-bootstrap';
//import HeartSyncBG from './assets/HeartSync_BG.jpg'; // Import the image
import Mrsuggestor from './assets/Mrsuggestor.jpg'; // Import the image
import Data from './assets/Data.jpg'; // Import the image
import Enhancement from './assets/Enhancement.jpg'; // Import the image



function CarouselComponent() {
  return (
    <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Data}
          alt="First slide"
        />
        <Carousel.Caption>
          <h3 style={{ color: 'black' }}>Visual Data Insights</h3>
          <p style={{ color: 'black' }}>View interactive pie charts to understand treatment distributions and trends..</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Mrsuggestor}
          alt="Second slide"
        />
        <Carousel.Caption>
          <h3 style={{ color: 'black' }}>Smart Treatment Recommendations </h3>
          <p style={{ color: 'black' }}>Use Mr. Suggestor, our assistant, to get treatment suggestions based on pain type, age, and gender.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={Enhancement}
          alt="Third slide"
        />
        <Carousel.Caption>
          <h3 style={{ color: 'black' }}>Enhance Medical Research</h3>
          <p style={{ color: 'black' }}>Streamline data analysis for medical professionals and researchers.</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default CarouselComponent;
