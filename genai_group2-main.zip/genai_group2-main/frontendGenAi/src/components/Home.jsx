import React from 'react';
import { Button, Container, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import CarouselComponent from './CarouselComponent';
import CardsComponent from './CardsComponent';
import Footer from './Footer';
import './HomePage.css';

function HomePage() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear any authentication tokens or user data here
    navigate('/login'); // Redirect to Login page
  };

  return (
    <div className="home-page">
      <div className="content">
        <Container>
          <Row className="justify-content-center align-items-center text-center">
            <Col md={6}>
              <h1 className="display-4 text-black">Welcome to HeartSync</h1>
              <p className="lead text-black">Your trusted cardiac diagnosis system</p>
              <Button variant="danger" size="lg" onClick={handleLogout}>Logout</Button>
            </Col>
          </Row>
        </Container>
      </div>
      <CarouselComponent />
      <CardsComponent />
      <Footer />
    </div>
  );
}

export default HomePage;
