import React from 'react';
import { Card, CardGroup } from 'react-bootstrap';
import './CardsComponent.css';
import Card1 from './assets/Card1.jpg'; // Import the image
import Card2 from './assets/Card2.jpg'; // Import the image
import Card3 from './assets/Card3.jpg'; // Import the image

function CardsComponent() {
  return (
    <CardGroup>
      <Card className="hover-card">
        <Card.Img variant="top" src={Card1} />
        <Card.Body>
          <Card.Title>Intuitive & User-Friendly Interface</Card.Title>
          <Card.Text>
            Easy navigation for seamless data analysis.
          </Card.Text>
        </Card.Body>
      </Card>
      <Card className="hover-card">
        <Card.Img variant="top" src={Card2}/>
        <Card.Body>
          <Card.Title>AI-Powered Treatment Suggestions</Card.Title>
          <Card.Text>
            Get personalized recommendations based on health data.
          </Card.Text>
        </Card.Body>
      </Card>
      <Card className="hover-card">
        <Card.Img variant="top" src={Card3} />
        <Card.Body>
          <Card.Title>Fast & Efficient Data Filtering </Card.Title>
          <Card.Text>
            Find relevant patient records in seconds.
          </Card.Text>
        </Card.Body>
      </Card>
    </CardGroup>
  );
}

export default CardsComponent;
